<!DOCTYPE html>
<html>
	<head>
		<title>DxWallet</title>
		<link rel="stylesheet" type="text/css" href="../css/homestyle.scss"/>
	</head>

	<body>

		<?php include '../helper/header.html'; ?>

        <h2>DxWallet - Aplicación básica para pagos en comercios autorizados</h2>
		
        <section class="margin">
            <h3>Sobre DxWallet</h3>
            <p>
                DxWallet es una aplicación desarrollada como parte de un proyecto de Final de Carrera de Ingeniería Informática.
                Mi objetivo principal es ofrecer una solución simple y segura para realizar pagos en comercios autorizados.
                La aplicación se ha diseñado pensando en la comodidad y la facilidad de uso para los usuarios, así como en 
				la seguridad de las transacciones.
            </p>
        </section>
        <section class="margin">
            <h3>Desarrollador</h3>
            <p>
                Soy un estudiante de Ingeniería Informática de la Universidad de La Laguna.
                Durante mi proyecto de Final de Carrera, he aplicado los conocimientos adquiridos 
				a lo largo de mis estudios para crear una aplicación funcional y escalable.
            </p>
        </section>
        <section class="margin">
            <h3>Contacto</h3>
            <p>
                Si tienes alguna pregunta o sugerencia sobre DxWallet, no dudes en ponerte en contacto conmigo.
                Puedes enviarme un correo electrónico a info@dxwallet.com o utilizar el formulario de contacto en la página web.
                ¡Estaré encantado de escucharte!
            </p>
        </section>
		
		<?php include '../helper/footer.html'; ?>

	</body>
</html>