<!DOCTYPE html>
<html>
<head>
  <title>Error</title>
  <link rel="stylesheet" type="text/css" href="/css/errorstyle.scss">
</head>
<body>
  <h1>Error - Usted no es un usuario con permisos para acceder</h1>
  <p>Lo sentimos, esta sección solo está disponible para usuarios 
  administradores de la plataforma, si cree que ha sido un fallo 
  de credenciales vuelva a intentarlo de nuevo.</p>
	<br><br>
	<form action="/index.php" method="POST">
		<div class="loginbtn" style="text-align: center;">
			<button type="submit" class="btn">Ir al home</button>
		</div>
	</form>
</body>
</html>
