<!DOCTYPE html>
<html>
<head>
  <title>DXWallet: Shop Panel</title>
  <link rel="stylesheet" type="text/css" href="/css/tablestyle.scss">
</head>

<body class="container">
  <h1>DXWallet: Tu monedero virtual</h1>


 <div>
 <h2>Datos del comercio</h2>
  <table id="shop-data">
    <tr>
      <th>DNI</th>
      <th>Nombre de cuenta</th>
	  <th>Nombre de comercio</th>
	  <th>Categoría</th>
	  <th>Email</th>
	  <th>Teléfono</th>
	  <th>Dirección</th>
    </tr>
	<tbody>
	
  <?php
 $user = $_GET['username'];
// $user = "comercio9";
// Crear la conexión a la base de datos
require_once 'connectdb.php';

// Verificar la conexión con la base de datos
if (!$conn) {
    die("Error conectando con la base de datos: " . mysqli_connect_error());
}
$latecif;
$sql = "SELECT dni_cif FROM Cuentas WHERE usuario = '$user'";
if ($result = mysqli_query($conn, $sql)) {
    if (mysqli_num_rows($result) != 0) {
		$row = mysqli_fetch_assoc($result);
		$cif = $row['dni_cif'];
		$latecif = $cif;
	} else {
        mysqli_close($conn);
		header("Location: loginerror.php");
		exit();
    }
}

$sql = "SELECT C.dni_cif AS dni, C.usuario AS usuario,
U.nombre AS nombre, U.telefono AS telefono, U.email AS email, U.direccion AS direccion,
T.nombre as categoria 
FROM Usuarios AS U INNER JOIN Cuentas AS C 
ON C.dni_cif=U.dni_cif INNER JOIN Comercios as M 
ON C.dni_cif = M.dni_cif INNER JOIN Categorias as T 
ON T.id = M.categoria WHERE C.dni_cif = '$cif'";

if ($result = mysqli_query($conn, $sql)) {
    if (mysqli_num_rows($result) != 0) {
        while ($row = mysqli_fetch_assoc($result)) {
            echo "<tr class='rowline'>
                <td>" . $row['dni'] . "</td>
				<td>" . $row['usuario'] . "</td>
                <td>" . $row['nombre'] . "</td>
				<td>" . $row['categoria'] . "</td>
				<td>" . $row['email'] . "</td>
				<td>" . $row['telefono'] . "</td>
				<td>" . $row['direccion'] . "</td>";
                echo "</tr>";
        }
    } else {
        echo "<tr><td colspan='6'> Ha ocurrido un error inesperado, por favor, vuelva a iniciar sesión para intentar cargar los datos de su comercio </td></tr>";
    }
}
?>
  </tbody>
  </table>
 </div>
<br><br>
</div>
  <div style="text-align:center;">
    <button onclick="openTab('new')">Nueva factura</button>
    <button onclick="openTab('invoices')">Facturas</button>
	<button onclick="openTab('mybcard')">Tarjeta</button>
  </div>
  <br><br>
  <div id="new" class="tab" style="display: none;">
	<h2>Nueva compra</h2>
	<form method="post" action="https://sebt.es/adexe/facturacion/genQR/index.php" target="ventana" name="Cobro_QR" onsubmit=mandar();>
<!--	<form method="post" action="popup.php" target="ventana" name="Cobro_QR" onsubmit=mandar();>
-->		
<!--
		<div class="form-group">
			<label for="Usuario">Nombre de usuario</label>
			<input type="text" name="Usuario" id="Usuario" class="form-control">
		</div><br>
		<div class="form-group">
			<label for="Ticket">Número de factura</label>
			<input type="text" name="Ticket" id="Ticket" class="form-control">
		</div><br>
		<div class="form-group">
			<label for="Importe">Importe de factura</label>
			<input type="text" name="Importe" id="Importe" class="form-control">
		</div>
-->
		<br><br>
		<div class="form-group">
			<input type="submit" name="submit" class="btn btn-primary" value="Cobrar">
<!--
			<input type="reset" name="reset" class="btn btn-primary" value="Reset">
-->
		</div>
	</form>
  </div>

  <div id="invoices" class="tab" style="display: none;">
  <h2>Facturas</h2>
  <table id="invoices-data">
    <tr>
      <th>Número de Factura</th>
      <th>Fecha</th>
	  <th>Importe</th>
	  <th>Moneda</th>
	  <th>Ticket</th>
	  <th>Cobrado</th>
    </tr>
	<tbody>
<?php
$sql = "SELECT * FROM Facturas WHERE cif_comercio = '$cif'";

if ($result = mysqli_query($conn, $sql)) {
	if(mysqli_num_rows($result) > 0){
		while ($row = mysqli_fetch_assoc($result)) {
			$tmp = $row['moneda'];
			$sql2 = "SELECT nombre FROM Monedas WHERE id = '$tmp'";
			if ($result2 = mysqli_query($conn, $sql2)) {
				$moneda = mysqli_fetch_assoc($result2);
				echo "<tr class='rowline'>
					<td>" . $row['numero_factura'] . "</td>
					<td>" . $row['fecha'] . "</td>
					<td>" . $row['importe'] . "</td>
					<td>" . $moneda['nombre'] . "</td>
					<td>" . $row['ticket'] . "</td>";
					if ($row['cobrado'] == 0) {
						echo "<td> No </td>";
					} else {
						echo "<td> Sí </td>";
					}
					echo "</tr>";
			}
		}
	} else {
		echo "<tr><td colspan='6'> No se encontraron facturas para su comercio </td></tr>";
	}
}
?>
  </tbody>
  </table>
 </div>
 
 
 <div id="mybcard" class="tab" style="display: none;">
 <h2>Tarjeta del comercio</h2>
  <table id="bcard-data">
    <tr>
      <th>Número de tarjeta</th>
      <th>Nombre de la tarjeta</th>
	  <th>Moneda asociada</th>
	  <th>Saldo</th>
    </tr>
	<tbody>
<?php
$sql = "SELECT * FROM Tarjetas WHERE cuenta = '$cif'";

if ($result = mysqli_query($conn, $sql)) {
	if(mysqli_num_rows($result) > 0){
		while ($row = mysqli_fetch_assoc($result)) {
			$tmp = $row['moneda'];
			$sql2 = "SELECT nombre FROM Monedas WHERE id = '$tmp'";
			if ($result2 = mysqli_query($conn, $sql2)) {
				$moneda = mysqli_fetch_assoc($result2);
				echo "<tr class='rowline'>
						<td>" . $row['numero_tarjeta'] . "</td>
						<td>" . $row['nombre'] . "</td>
						<td>" . $moneda['nombre'] . "</td>
						<td>" . $row['saldo'] . "</td></tr>";
				
			}
		}
	} else {
		echo "<tr><td colspan='4'> No se encontraron tarjetas para su comercio </td></tr>";
	}
}

mysqli_close($conn);
?>
  </tbody>
  </table>
  <br><br>
  	<div class="habilitar">
		<h2>Modificar datos</h2>
		<h3> Nota: Ni el DNI ni la moneda se pueden modificar. Si usted marcó que quería una moneda personalizada, un administrador se pondrá en contacto con usted para tramitarlo. Si por el contrario detectó algún error en alguno de los dos campos indicados, <a href="#" style="color: blue; text-decoration: underline;">contacte aquí.</a></h3> 
		<form action="../helper/actions/modshop.php" method="POST">
			<br>
			<div class="form-group" style="display: none;">
				<label for="dni">DNI: </label>
				<input type="text" name="dni" id="dni" required value="<?php echo $latecif; ?>">
			</div>
			<div class="form-group">
				<label for="accountName">Nombre de cuenta: </label>
				<input type="text" name="accountName" id="accountName">
			</div>
			<br>
			<div class="form-group">
				<label for="shopName">Nombre de comercio: </label>
				<input type="text" name="shopName" id="shopName">
			</div>
			<br>
			<div class="form-group">
				<label for="category">Categoría: </label>
				<input type="text" name="category" id="category">
			</div>
			<br>
			<div class="form-group">
				<label for="email">Email: </label>
				<input type="text" name="email" id="email">
			</div>
			<br>
			<div class="form-group">
				<label for="phone">Teléfono: </label>
				<input type="text" name="phone" id="phone">
			</div>
			<br>
			<div class="form-group">
				<label for="address">Dirección: </label>
				<input type="text" name="address" id="address">
			</div>
			<br>
			<div class="form-group">
				<label for="visaName">Nombre de tarjeta: </label>
				<input type="text" name="visaName" id="visaName">
			</div>
			<br>
			<div class="loginbtn">
				<button type="submit" class="btn">Modificar</button>
			</div>
		</form>
	</div>
  </div>

  </div>

	<script> document.getElementById("invoices").style.display = "block";</script>
	<br><br>
	<form action="/index.php" method="POST">
		<div class="loginbtn" style="text-align: center;">
			<button type="submit" class="btn">Salir</button>
		</div>
	</form>
	
	<script src="/js/popupscript.js"></script> 
	<script src="/js/tablescript.js"></script> 
</body>
</html>
