<!DOCTYPE html>
<html>
	<head>
		<title>DxWallet</title>
		<link rel="stylesheet" type="text/css" href="../css/homestyle.scss"/>
	</head>

	<body>
		<?php include '../helper/header.html'; ?>
		<div class="margin">

			<h2>Contacto</h2>
			<p>Puedes ponerte en contacto con nosotros a través de la dirección de correo electrónico info@dxwallet.com 
			o hacernos una visita, ¡Te estaremos esperando!</p>
			<pre>
										  <img class="mapa" src="/img/tenerife.png" alt="Mapa de Santa Cruz de Tenerife">

									   Camino San Francisco de Paula, 19, 
									38203 La Laguna, Santa Cruz de Tenerife 
										   Islas Canarias, España.
			</pre>
			<br>
		</div>
		<?php include '../helper/footer.html'; ?>

	</body>
</html>