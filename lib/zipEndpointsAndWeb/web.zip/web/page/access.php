<!DOCTYPE html>
<html>
	<head>
		<title>DxWallet</title>
		<link rel="stylesheet" type="text/css" href="../css/homestyle.scss"/>
	</head>

	<body>
		<?php include '../helper/header.html'; ?>
		<div class="margin">
			<h2>Accesibilidad web</h2>
			
			<h3>Compatibilidad con Lectores de Pantalla</h3>
			<p>Esta página ha sido diseñada para ser compatible con lectores de pantalla. Se han utilizado etiquetas semánticas 
			apropiadas y se han proporcionado atributos alt para las imágenes.</p>
			
			<h3>Teclado y Navegación</h3>
			<p>Se pueden utilizar las teclas de tabulación para navegar por los elementos interactivos de la página. Se han 
			proporcionado puntos de enfoque visuales para indicar la navegación por teclado.</p>
			
			<h3>Texto Alternativo para Imágenes</h3>
			<p>Se ha proporcionado texto alternativo descriptivo para todas las imágenes para que los usuarios con discapacidad 
			visual puedan comprender el contenido de las imágenes.</p>
			
			<h3>Compatibilidad con Colores</h3>
			<p>Se ha tenido en cuenta la legibilidad y el contraste de los colores utilizados en el diseño de la página para 
			asegurar una buena accesibilidad para las personas con dificultades visuales.</p>
			
			<h3>Enlaces Descriptivos</h3>
			<p>Se han utilizado enlaces descriptivos que explican claramente el destino del enlace para que los usuarios de 
			lectores de pantalla puedan comprender el contexto del enlace.</p>
			
			<h3>Contenido Alternativo</h3>
			<p>Se ha proporcionado contenido alternativo para los elementos multimedia y otros contenidos no textuales, 
			como videos o audio, para que los usuarios con discapacidad puedan acceder a la información.</p>
		</div>
		<?php include '../helper/footer.html'; ?>
	</body>
</html>