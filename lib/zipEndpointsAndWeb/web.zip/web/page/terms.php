<!DOCTYPE html>
<html>
	<head>
		<title>DxWallet</title>
		<link rel="stylesheet" type="text/css" href="../css/homestyle.scss"/>
	</head>

	<body>
		<?php include '../helper/header.html'; ?>
		<div class="margin">
			<h2>Términos y Condiciones</h2>
			<p>Por favor, lea estos términos y condiciones cuidadosamente antes de utilizar este sitio web.</p>
			
			<h3>Aceptación de los Términos</h3>
			<p>Al acceder y utilizar este sitio web, usted acepta cumplir y estar sujeto a estos términos y condiciones. Si no está de acuerdo con alguno de los términos, no utilice este sitio web.</p>
			
			<h3>Propiedad Intelectual</h3>
			<p>Todos los contenidos de este sitio web, incluyendo textos, gráficos, logotipos, imágenes y software, están protegidos por las leyes de propiedad intelectual y son propiedad de la compañía o de sus proveedores de contenido.</p>
			
			<h3>Uso del Sitio Web</h3>
			<p>Este sitio web se proporciona únicamente con fines informativos. Usted acepta utilizar este sitio web de manera responsable y respetar todas las leyes y regulaciones aplicables.</p>
			
			<h3>Limitación de Responsabilidad</h3>
			<p>La compañía no se hace responsable de ningún daño directo, indirecto, incidental, consecuencial o especial derivado del uso o la incapacidad de uso de este sitio web.</p>
			
			<h3>Enlaces a Sitios de Terceros</h3>
			<p>Este sitio web puede contener enlaces a sitios web de terceros. Estos enlaces se proporcionan únicamente para su conveniencia y no implican respaldo o afiliación con esos sitios. La compañía no tiene control sobre el contenido de los sitios web de terceros y no asume ninguna responsabilidad por ellos.</p>
			
			<h3>Modificaciones</h3>
			<p>La compañía se reserva el derecho de modificar estos términos y condiciones en cualquier momento sin previo aviso. Se recomienda revisar periódicamente esta página para estar al tanto de los cambios.</p>
			
			<h3>Contacto</h3>
			<p>Si tiene alguna pregunta o duda acerca de estos términos y condiciones, puede ponerse en contacto con nosotros a través de la información de contacto proporcionada en este sitio web.</p>
		</div>

		<?php include '../helper/footer.html'; ?>

	</body>
</html>