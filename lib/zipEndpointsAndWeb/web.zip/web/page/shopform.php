<!DOCTYPE html>
<html>
	<head>
	<title>DxWallet: Registro</title>
		<link rel="stylesheet" type="text/css" href="../css/login.scss"/>
		<link rel="stylesheet" href="../css/styles.scss">	
	</head>

	<body>
		<?php include '../helper/header.html'; ?>

		<div id="weblogin" class="margin">
			<img src="/img/LogoCuadrado.png"/>
			<br>
			<h2>Inscripción de un nuevo comercio</h2>
			<br>
			<form action="/helper/signup.php" method="POST">
				<h3>Datos de identificación del comercio:</h3>
				<div class="form-group">
					<label for="name">Nombre: </label>
					<input type="text" name="name" id="name" required>
					</div>
				<br>
				<div class="form-group">
					<label for="cif">DNI/CIF: </label>
					<input type="text" name="cif" id="cif" required>
				</div>
				<br>
				<h3>Datos de contacto del comercio:</h3>
				<div class="form-group">
					<label for="dir">Dirección: </label>
					<input type="text" name="dir" id="dir" required>
				</div>
				<br>
				<div class="form-group">
					<label for="tel">Teléfono: </label>
					<input type="text" name="tel" id="tel" required>
				</div>
				<br>
				<h3>Datos para la gestión de la cuenta:</h3>
				<div class="form-group">
					<label for="email">Correo electrónico: </label>
					<input type="text" name="email" id="email" required>
				</div>
				<br>
				<div class="form-group">
					<label for="username">Nombre de cuenta: </label>
					<input type="text" name="username" id="username" required>
				</div>
				<br>
				<?php
				$randomNumber = "4";
				// Generamos los 15 dígitos restantes
				for ($i = 1; $i < 16; $i++) {
					$randomNumber .= mt_rand(0, 9); // Concatenamos un dígito aleatorio del 0 al 9
				}
				?>

				<div class="form-group" style="display: none;">
				  <label for="username">Número de tarjeta: </label>
				  <input type="text" name="visa" id="visa" required value="<?php echo $randomNumber; ?>">
				</div>
<?php
// Crea la conexión
require_once 'connectdb.php';

// Consulta SQL para obtener las monedas
$sql = "SELECT id, nombre FROM Monedas";
$result = mysqli_query($conn, $sql);

?>
        <div class="form-group">
            <label for="currency">Moneda:</label>
            <select name="currency" id="currency" required>
                <?php
                if (mysqli_num_rows($result) > 0) {
                    while ($row = mysqli_fetch_assoc($result)) {
                        echo '<option id="currency" value="' . (int)$row['id'] . '">' . $row['nombre'] . '</option>';
                    }
                } else {
                    echo '<option value="">No se encontraron monedas disponibles</option>';
                }
                ?>
            </select>
        </div>
		<br>
<?php
// Cierra la conexión a la base de datos
mysqli_close($conn);
?>
				<div class="form-group">
					<input type="checkbox" id="solicitar-moneda">
					<label for="solicitar-moneda">* Solicitar nueva moneda</label>
				</div>
				<br>
				<div class="form-group">
					<label for="password">Contraseña: </label>
					<input type="password" name="password" id="password" required>
				</div>
				<br>
				
				<div class="loginbtn">
					<button type="submit" class="btn">Solicitar inscripción</button>
				</div>
				<br>
			</form>
			<div class="">
				<label for="solicitar-moneda-info">(* Un administrador contactará con usted en breve)</label>
			</div>
		</div>
		<?php include '../helper/footer.html'; ?>
	</body>
</html>