<!DOCTYPE html>
<html>
	<head>
		<title>DxWallet: Login</title> 
		<link rel="stylesheet" href="../css/styles.scss">
	</head>

	<body>
		<?php include '../helper/header.html'; ?>
			<section class="features">
				<div class="container">
				  <h2 class="section-title">Disponible para todas las plataformas</h2>
				  <div class="feature">
					<h3>Descarga para dispositivos android</h3>
					<a href="https://play.google.com/store/" class="btn"><img class="applogo" src="/img/android.png" alt="Descargar en la play store de android"/></a>
				  </div>
				  <div class="feature">
					<h3>Descarga para dispositivos apple</h3>
					<a href="https://www.apple.com/es/store" class="btn"><img class="applogo" src="/img/apple.png" alt="Descargar en la app store de apple"/></a>
				  </div>
				</div>
			  </section>
			<p class="aviso"> <img src="/img/aviso.png" alt="Icono de información"/> Los usuarios deben registrarse haciendo uso de la aplicación. Únicamente los comercios, son los que pueden inscribirse a través del portal web. </p>

		<?php include '../helper/footer.html'; ?>
	</body>
</html>