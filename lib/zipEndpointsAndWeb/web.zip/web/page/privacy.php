<!DOCTYPE html>
<html>
	<head>
		<title>DxWallet</title>
		<link rel="stylesheet" type="text/css" href="../css/homestyle.scss"/>
	</head>

	<body>
		<?php include '../helper/header.html'; ?>
		<div class="margin">
			<h2>Política de Privacidad</h2>
			<p>En esta página se describe cómo se recopila, utiliza y protege la información personal que se obtiene a través de este sitio web.</p>
			
			<h3>Información Recopilada</h3>
			<p>Se recopila información personal, como nombres, direcciones de correo electrónico y otros datos, solo cuando se proporcionan voluntariamente a través de formularios de contacto u otros medios de comunicación.</p>
			
			<h3>Uso de la Información</h3>
			<p>La información personal recopilada se utiliza únicamente para los fines específicos para los que se proporcionó. No se compartirá ni venderá a terceros sin el consentimiento explícito del titular de la información, excepto cuando sea requerido por ley.</p>
			
			<h3>Cookies y Tecnologías Similares</h3>
			<p>Este sitio web puede utilizar cookies y tecnologías similares para mejorar la experiencia del usuario y recopilar información sobre el uso del sitio. Puede ajustar la configuración de su navegador para rechazar cookies, pero esto puede afectar el funcionamiento del sitio.</p>
			
			<h3>Enlaces a Sitios de Terceros</h3>
			<p>Este sitio web puede contener enlaces a sitios web de terceros. No nos responsabilizamos por el contenido o las prácticas de privacidad de dichos sitios y se recomienda revisar las políticas de privacidad correspondientes.</p>
			
			<h3>Seguridad de la Información</h3>
			<p>Se han implementado medidas de seguridad razonables para proteger la información personal recopilada. Sin embargo, no se puede garantizar la seguridad completa de la información transmitida a través de Internet.</p>
			
			<h3>Derechos del Usuario</h3>
			<p>Los usuarios tienen derecho a acceder, corregir y eliminar su información personal, así como a ejercer otros derechos relacionados con la privacidad de acuerdo con las leyes y regulaciones aplicables.</p>
			
			<h3>Modificaciones</h3>
			<p>Nos reservamos el derecho de modificar esta política de privacidad en cualquier momento. Cualquier cambio se publicará en esta página y se considerará aceptado al continuar utilizando el sitio web después de dichas modificaciones.</p>
			
			<h3>Contacto</h3>
			<p>Si tiene alguna pregunta o inquietud acerca de esta política de privacidad, puede ponerse en contacto con nosotros a través de la información de contacto proporcionada en este sitio web.</p>
		</div>
		<?php include '../helper/footer.html'; ?>
	</body>
</html>