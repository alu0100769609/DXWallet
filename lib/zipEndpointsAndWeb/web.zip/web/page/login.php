<!DOCTYPE html>
<html>
	<head>
		<title>DxWallet: Login</title>
		<link rel="stylesheet" type="text/css" href="../css/login.scss"/>
		<link rel="stylesheet" href="../css/styles.scss">
	</head>

	<body>
		<?php include '../helper/header.html'; ?>
		<div id="weblogin" class="margin">
			<img src="/img/LogoCuadrado.png"/>
			<h2>Acceso al panel administrativo DXWALLET</h2>
			<form action="/helper/login.php" method="POST">
				<div class="form-group">
					<label for="username">Nombre de usuario: </label>
					<input type="text" name="username" id="username" required>
				</div>
				<br>
				<div class="form-group">
					<label for="password">Clave de seguridad: </label>
					<input type="password" name="password" id="password" required>
				</div>
				<br>
				
				<div class="loginbtn">
					<button type="submit" class="btn">Acceder</button>
				</div>
				<br>
			</form>
			<a class="loginlink" href="/page/contact.php">No recuerdo la contraseña</a><br>
			<a class="loginlink" href="/page/userform.php">Soy un nuevo usuario</a><br>
			<a class="loginlink" href="/page/shopform.php">Soy un nuevo comercio</a><br>
		</div>
		<?php include '../helper/footer.html'; ?>
	</body>
</html>