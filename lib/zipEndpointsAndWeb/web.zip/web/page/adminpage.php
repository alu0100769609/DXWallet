<!DOCTYPE html>
<html>
<head>
  <title>DXWallet: Admin Panel</title>
  <link rel="stylesheet" type="text/css" href="/css/tablestyle.scss">
</head>

<body class="container">
  <h1>DXWallet: Tu monedero virtual</h1>
  
  <div style="text-align:center;">
    <button onclick="openTab('users')">Usuarios</button>
    <button onclick="openTab('shops')">Comercios</button>
    <button onclick="openTab('admins')">Administradores</button>
	<button onclick="openTab('bcards')">Tarjetas</button>
	<button onclick="openTab('curren')">Monedas</button>
	<button onclick="openTab('roles')">Roles</button>
  </div>
  
  <div id="users" class="tab" style="display: none;">
  <h2>Datos de los usuarios</h2>
  <table id="user-data">
    <tr>
      <th>DNI</th>
      <th>Nombre de usuario</th>
	  <th>Nombre completo</th>
	  <th>Email</th>
	  <th>Teléfono</th>
	  <th>Dirección</th>
	  <th>Cuenta activa</th>
    </tr>
	<tbody>
<?php
// Crear la conexión a la base de datos
require_once 'connectdb.php';

// Verificar la conexión con la base de datos
if (!$conn) {
    die("Error conectando con la base de datos: " . mysqli_connect_error());
}
$sql = "SELECT C.dni_cif AS dni, C.usuario AS usuario,  C.habilitado AS habilitado,
U.nombre AS nombre, U.telefono AS telefono, U.email AS email, U.direccion AS direccion,
U.apellido1 AS apellido1, U.apellido2 AS apellido2
FROM Usuarios AS U INNER JOIN Cuentas AS C 
ON C.dni_cif=U.dni_cif WHERE C.rol LIKE 3";

if ($result = mysqli_query($conn, $sql)) {
    if (mysqli_num_rows($result) != 0) {
        while ($row = mysqli_fetch_assoc($result)) {
            echo "<tr class='rowline'>
                <td>" . $row['dni'] . "</td>
				<td>" . $row['usuario'] . "</td>
                <td>" . $row['nombre'] . " " . $row['apellido1'] . " " . $row['apellido2'] . "</td>
				<td>" . $row['email'] . "</td>
				<td>" . $row['telefono'] . "</td>
				<td>" . $row['direccion'] . "</td>";
				if ($row['habilitado'] == 0) {
					echo "<td> No </td>";
				} else {
					echo "<td> Sí </td>";
				}
                echo "</tr>";
        }
    } else {
        echo "<tr><td colspan='6'> No se encontraron usuarios registrados </td></tr>";
    }
}
?>
  </tbody>
  </table>
  
	<div class="eliminar">
		<h2>Eliminar un usuario</h2>
		<h3> Nota: Si decide eliminar un usuario, será eliminado por completo 
		y no podrá recuperarlo. Si solo necesita desactivarlo, mejor diríjase a la sección de deshabilitar usuario.</h3> 
		<form action="../helper/actions/deluser.php" method="POST">
			<div class="form-group">
				<label for="dni">Dni del usuario: </label>
				<input type="text" name="dni" id="dni" required>
			</div>
			<br>
			<div class="loginbtn">
				<button type="submit" class="btn">Eliminar</button>
			</div>
		</form>
	</div>
  
	<div class="habilitar">
		<h2>Habilitar o deshabilitar un usuario</h2>
		<h3> Nota: Si el usuario está habilitado, se deshabilitará. Si el usuario está deshabilitado, se habilitará.</h3> 
		<form action="../helper/actions/habuser.php" method="POST">
			<div class="form-group">
				<label for="dni">Dni del usuario: </label>
				<input type="text" name="dni" id="dni" required>
			</div>
			<br>
			<div class="loginbtn">
				<button type="submit" class="btn">Activar/desactivar</button>
			</div>
		</form>
	</div>
    
  </div>
 
 <div id="shops" class="tab" style="display: none;">
 <h2>Datos de los comercios</h2>
  <table id="shop-data">
    <tr>
      <th>DNI</th>
      <th>Nombre de cuenta</th>
	  <th>Nombre de comercio</th>
	  <th>Email</th>
	  <th>Teléfono</th>
	  <th>Dirección</th>
	  <th>Cuenta activa</th>
    </tr>
	<tbody>
<?php

$sql = "SELECT C.dni_cif AS dni, C.usuario AS usuario, C.habilitado AS habilitado,
U.nombre AS nombre, U.telefono AS telefono, U.email AS email, U.direccion AS direccion
FROM Usuarios AS U INNER JOIN Cuentas AS C 
ON C.dni_cif=U.dni_cif WHERE C.rol LIKE 2";

if ($result = mysqli_query($conn, $sql)) {
    if (mysqli_num_rows($result) != 0) {
        while ($row = mysqli_fetch_assoc($result)) {
            echo "<tr class='rowline'>
                <td>" . $row['dni'] . "</td>
				<td>" . $row['usuario'] . "</td>
                <td>" . $row['nombre'] . "</td>
				<td>" . $row['email'] . "</td>
				<td>" . $row['telefono'] . "</td>
				<td>" . $row['direccion'] . "</td>";
				if ($row['habilitado'] == 0) {
					echo "<td> No </td>";
				} else {
					echo "<td> Sí </td>";
				}
                echo "</tr>";
        }
    } else {
        echo "<tr><td colspan='5'> No se encontraron comercios registrados </td></tr>";
    }
}
?>
  </tbody>
  </table>
  
  <div class="eliminar">
		<h2>Eliminar un comercio</h2>
		<h3> Nota: Si decide eliminar un comercio, será eliminado por completo 
		y no podrá recuperarlo. Si solo necesita desactivarlo, mejor diríjase a la sección de deshabilitar comercio.</h3> 
		<form action="../helper/actions/delshop.php" method="POST">
			<div class="form-group">
				<label for="dni">Dni o cif del comercio: </label>
				<input type="text" name="dni" id="dni" required>
			</div>
			<br>
			<div class="loginbtn">
				<button type="submit" class="btn">Eliminar</button>
			</div>
		</form>
	</div>
  
	<div class="habilitar">
		<h2>Habilitar o deshabilitar un comercio</h2>
		<h3> Nota: Si el comercio está habilitado, se deshabilitará. Si el comercio está deshabilitado, se habilitará.</h3> 
		<form action="../helper/actions/habshop.php" method="POST">
			<div class="form-group">
				<label for="dni">Dni o cif del comercio: </label>
				<input type="text" name="dni" id="dni" required>
			</div>
			<br>
			<div class="loginbtn">
				<button type="submit" class="btn">Activar/desactivar</button>
			</div>
		</form>
	</div>
  </div>
  
  <div id="admins" class="tab" style="display: none;">
  <h2>Datos de los administradores</h2>
  <table id="admin-data">
    <tr>
      <th>DNI</th>
      <th>Nombre de usuario</th>
	  <th>Nombre completo</th>
	  <th>Email</th>
	  <th>Teléfono</th>
	  <th>Dirección</th>
	  <th>Cuenta activa</th>
    </tr>
	<tbody>
<?php
$sql = "SELECT C.dni_cif AS dni, C.usuario AS usuario,  C.habilitado AS habilitado,
U.nombre AS nombre, U.telefono AS telefono, U.email AS email, U.direccion AS direccion,
U.apellido1 AS apellido1, U.apellido2 AS apellido2
FROM Usuarios AS U INNER JOIN Cuentas AS C 
ON C.dni_cif=U.dni_cif WHERE C.rol LIKE 1";

if ($result = mysqli_query($conn, $sql)) {
    if (mysqli_num_rows($result) != 0) {
        while ($row = mysqli_fetch_assoc($result)) {
            echo "<tr class='rowline'>
                <td>" . $row['dni'] . "</td>
				<td>" . $row['usuario'] . "</td>
                <td>" . $row['nombre'] . " " . $row['apellido1'] . " " . $row['apellido2'] . "</td>
				<td>" . $row['email'] . "</td>
				<td>" . $row['telefono'] . "</td>
				<td>" . $row['direccion'] . "</td>";
				if ($row['habilitado'] == 0) {
					echo "<td> No </td>";
				} else {
					echo "<td> Sí </td>";
				}
                echo "</tr>";
        }
    } else {
        echo "<tr><td colspan='6'> No se encontraron administradores registrados </td></tr>";
    }
}
?>
  </tbody>
  </table>
  
  <div class="eliminar">
		<h2>Eliminar un administrador</h2>
		<h3> Nota: Si decide eliminar un administrador, será eliminado por completo 
		y no podrá recuperarlo. Recuerde que siempre debe permanecer un administrador en la lista.</h3> 
		<form action="../helper/actions/deladmin.php" method="POST">
			<div class="form-group">
				<label for="dni">Dni del administrador: </label>
				<input type="text" name="dni" id="dni" required>
			</div>
			<br>
			<div class="loginbtn">
				<button type="submit" class="btn">Eliminar</button>
			</div>
		</form>
	</div>
  
	<div class="insertar">
		<h2>Agregar un nuevo administrador</h2>
		<h3> Nota: Para agregar un nuevo administrador, se creará una nueva cuenta de usuario con los datos mínimos, 
		asignando rol de administrador.</h3> 
		<form action="../helper/actions/insadmin.php" method="POST">
			<div class="form-group">
				<label for="dni">Dni del nuevo administrador: </label>
				<input type="text" name="dni" id="dni" required>
			</div>
			<br>
			<div class="form-group">
				<label for="nombre">Nombre del nuevo administrador: </label>
				<input type="text" name="nombre" id="nombre" required>
			</div>
			<br>
			<div class="form-group">
				<label for="email">Email del nuevo administrador: </label>
				<input type="text" name="email" id="email" required>
			</div>
			<br>
			<div class="form-group">
				<label for="user">Nombre de usuario del nuevo administrador: </label>
				<input type="text" name="user" id="user" required>
			</div>
			<br>
			<div class="form-group">
				<label for="pass">Contraseña del nuevo administrador: </label>
				<input type="password" name="pass" id="pass" required>
			</div>
			<br>
			<div class="form-group">
				<label for="tel">Teléfono del nuevo administrador: </label>
				<input type="text" name="tel" id="tel" required>
			</div>
			<br>
			<div class="form-group">
				<label for="dir">Dirección del nuevo administrador: </label>
				<input type="text" name="dir" id="dir" required>
			</div>
			<br>
			<div class="loginbtn">
				<button type="submit" class="btn">Agregar</button>
			</div>
		</form>
	</div>
  
  </div>
  
  <div id="bcards" class="tab" style="display: none;">
  <h2>Tarjetas activas</h2>
  <table id="bank-cards">
    <tr>
      <th>DNI del usuario</th>
      <th>Numero de tarjeta</th>
    </tr>
	<tbody>
<?php
$sql = "SELECT * FROM Tarjetas";

if ($result = mysqli_query($conn, $sql)) {
    if (mysqli_num_rows($result) != 0) {
        while ($row = mysqli_fetch_assoc($result)) {
            echo "<tr class=rowline>";
			echo "<td>" . $row["cuenta"] . "</td>";
			echo "<td>************" . substr($row["numero_tarjeta"], -4) . "</td>";
			echo "</tr>";
        }
    } else {
        echo "<tr><td colspan='6'> No se encontraron tarjetas registradas </td></tr>";
    }
}
?>
	</tbody>
	</table>
	</div>
	
	<div id="curren" class="tab" style="display: none;">
  <h2>Monedas disponibles</h2>
  <table id="currencies">
    <tr>
      <th>ID</th>
      <th>Moneda</th>
	  <th>Símbolo</th>
    </tr>
	<tbody>
<?php
$sql = "SELECT * FROM Monedas";

if ($result = mysqli_query($conn, $sql)) {
    if (mysqli_num_rows($result) != 0) {
        while ($row = mysqli_fetch_assoc($result)) {
            echo "<tr class=rowline>";
			echo "<td>" . $row["id"] . "</td>";
			echo "<td>" . $row["nombre"] . "</td>";
			echo "<td>" . $row["simbolo"] . "</td>";
			echo "</tr>";
        }
    } else {
        echo "<tr><td colspan='6'> No se encontraron monedas registradas </td></tr>";
    }
}
?>
	</tbody>
	</table>
	
	<div class="eliminar">
		<h2>Eliminar una moneda</h2>
		<h3> Nota: Si decide eliminar una moneda, será eliminada por completo 
		y no podrá recuperarla.</h3> 
		<form action="../helper/actions/delcurrency.php" method="POST">
			<div class="form-group">
				<label for="id">Identificador numérico (id): </label>
				<input type="text" name="id" id="id" required>
			</div>
			<br>
			<div class="loginbtn">
				<button type="submit" class="btn">Eliminar</button>
			</div>
		</form>
	</div>
  
	<div class="insertar">
		<h2>Agregar una nueva moneda</h2>
		<h3> Nota: Para agregar una nueva moneda, se deben completar todos los datos que se solicitan.</h3> 
		<form action="../helper/actions/inscurrency.php" method="POST">
			<div class="form-group">
				<label for="id">Identificador numérico (id): </label>
				<input type="text" name="id" id="id" required>
			</div>
			<br>
			<div class="form-group">
				<label for="nombre">Nombre de la moneda: </label>
				<input type="text" name="nombre" id="nombre" required>
			</div>
			<br>
			<div class="form-group">
				<label for="simbol">Símbolo de la moneda: </label>
				<input type="text" name="simbol" id="simbol" required>
			</div>
			<br>
			<div class="loginbtn">
				<button type="submit" class="btn">Agregar</button>
			</div>
		</form>
	</div>	
	
	</div>
	
	
	<div id="roles" class="tab" style="display: none;">
  <h2>Roles disponibles</h2>
  <table id="roles">
    <tr>
      <th>ID</th>
      <th>Rol</th>
    </tr>
	<tbody>
<?php
$sql = "SELECT * FROM Roles";

if ($result = mysqli_query($conn, $sql)) {
    if (mysqli_num_rows($result) != 0) {
        while ($row = mysqli_fetch_assoc($result)) {
            echo "<tr class=rowline>";
			echo "<td>" . $row["id"] . "</td>";
			echo "<td>" . $row["nombre"] . "</td>";
			echo "</tr>";
        }
    } else {
        echo "<tr><td colspan='6'> No se encontraron roles registrados </td></tr>";
    }
}
mysqli_close($conn);
?>
	</tbody>
	</table>
	
	<div class="eliminar">
		<h2>Eliminar un rol</h2>
		<h3> Nota: Si decide eliminar un rol, será eliminado por completo 
		y no podrá recuperarlo.</h3> 
		<form action="../helper/actions/delrol.php" method="POST">
			<div class="form-group">
				<label for="id">Identificador numérico (id): </label>
				<input type="text" name="id" id="id" required>
			</div>
			<br>
			<div class="loginbtn">
				<button type="submit" class="btn">Eliminar</button>
			</div>
		</form>
	</div>
  
	<div class="insertar">
		<h2>Agregar un nuevo rol</h2>
		<h3> Nota: Para agregar un nuevo rol, se deben completar todos los datos que se solicitan.</h3> 
		<form action="../helper/actions/insrol.php" method="POST">
			<div class="form-group">
				<label for="id">Identificador numérico (id): </label>
				<input type="text" name="id" id="id" required>
			</div>
			<br>
			<div class="form-group">
				<label for="nombre">Nombre del rol: </label>
				<input type="text" name="nombre" id="nombre" required>
			</div>
			<br>
			<div class="loginbtn">
				<button type="submit" class="btn">Agregar</button>
			</div>
		</form>
	</div>
	
	</div>
	
	<script> document.getElementById("users").style.display = "block";</script>
	<br><br>
	<form action="/index.php" method="POST">
		<div class="loginbtn" style="text-align: center;">
			<button type="submit" class="btn">Salir</button>
		</div>
	</form>
	<br><br>
	<script src="/js/editscript.js"></script> 
	<script src="/js/tablescript.js"></script> 
</body>
</html>
