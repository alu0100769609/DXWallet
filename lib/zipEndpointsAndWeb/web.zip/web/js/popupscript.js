	
	//Script que abre un popup con el QR y que contiene el código de comprobación de pago
	var popup = null;
	function mandar()
	{
		// Si el popup ya existe lo cerramos
		if(popup!=null)
			popup.close();

		// Capturamos las dimensiones de la pantalla para centrar el popup
		altoPantalla = parseInt(screen.availHeight);
		anchoPantalla = parseInt(screen.availWidth);
		
		// Calculamos el centro de la pantalla
		centroAncho = parseInt((anchoPantalla/2))
		centroAlto = parseInt((altoPantalla/2))

		// dimensiones del popup
		anchoPopup = 500;
		altoPopup = 350;

		// Calculamos las coordenadas de colocación del Popup
		laXPopup = centroAncho - parseInt((anchoPopup/2))
		laYPopup = centroAlto - parseInt((altoPopup/2))
		
		// Definimos que página vamos a ver
		pagina = "recursos/popup.php";
		
		//Se abre el popup con los parámetros configurados
		window.open(pagina,"ventana","scrollbars=no,status=no,toolbar=no,location=no,menubar=no,resizable=no,titlebar=no,title=no,width=" + anchoPopup + ", height=" + altoPopup + ",left = " + laXPopup + ",top = " + laYPopup);
	}