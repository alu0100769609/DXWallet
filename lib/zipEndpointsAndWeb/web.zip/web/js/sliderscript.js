/* Script para que el Carrusel cambie la imagen en un tiempo predefinido. */
var slides = document.getElementsByClassName("slide");
var currentslide = 0;
var slideinterval = setInterval(nextslide, 3000);

function nextslide() {
  slides[currentslide].style.display = 'none';
  currentslide = (currentslide + 1) % slides.length;
  slides[currentslide].style.display = 'block';
}