	//Rellenar textos e imágenes
	$(".instrucciones").html('<b>Escanee el códogo QR y espere confirmación</b>');
	$(".esperando").html('Esperando confirmación...');
	$(".comprobacion").html('<img src="/img/loading-cargando.gif" height="40" width="40" />');
	
	var Confirmado = "";
	var datos = "Usuario: " + '<?=$usuario?>' + "\n" + "Ticket: " + '<?=$ticket?>';
	//Generar QR
	function Generar() {
		$.ajax({
			url:'/helper/qrgenerate/generate_code.php',
			type:'POST',
			data: {formData:datos, ecc:"H", size:5, marco:5,Desde:"Facturacion", Usuario:'<?=$usuario?>', Ticket:'<?=$ticket?>'},
			success: function(response) {
				$(".showQRCode").html(response);
			},
		});
	}
	//Enviar facturación a cobro
	function Facturar() {
		$.ajax({
			url:'/helper/invoices/facturar.php',
			type:'POST',
			data: {Usuario:'<?=$usuario?>', Ticket:'<?=$ticket?>'},
			dataType:'JSON',
			success: function(response) {
				Confirmado = response.Estado;
			},
			error: function(response) {
				Confirmado = "Error";
			},
		});
	}
	//Esperar comprobación
	function Comprobar(){
		if (Confirmado == "Grabado"){
			$.ajax({
				url:'/helper/invoices/comprobarEnTabla.php',
				type:'POST',
				data: {Usuario:'<?=$usuario?>', Ticket:'<?=$ticket?>'},
				dataType:'JSON',
				success: function(response) {
					if (response.Estado == "OK"){
						$(".instrucciones").html('<b>PAGO CONFIRMADO</b>');
						$(".esperando").html('');
						$(".showQRCode").html('');
						$(".comprobacion").html('<img src="/img/check.png" height="100" width="100" />');
						Confirmado = response.Estado;
					}
					else {
						Confirmado = "Grabado";
					}
				},
				error: function(response) {
					$(".instrucciones").html('<b>ERROR EN EL PROCESO DE PAGO</b>');
					$(".esperando").html('');
					$(".showQRCode").html('');
					Confirmado = response.Estado;
				},
			});
		}
		else if (Confirmado == "Error"){
			$(".instrucciones").html('<b>ERROR EN EL PROCESO DE PAGO</b>');
			$(".esperando").html('');
			$(".showQRCode").html('');
			$(".comprobacion").html('<img src="/img/error.png" height="100" width="100" />');
			clearInterval(bucle);
		}
		else if (Confirmado == "OK"){
			clearInterval(bucle);
		}
		else {
			clearInterval(bucle);
		}
		console.log("Esperando...");
	}
	Generar();
	Facturar();
	const bucle = setInterval('Comprobar()',2000);