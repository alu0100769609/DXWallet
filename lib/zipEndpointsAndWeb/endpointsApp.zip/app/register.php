<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST'){
	$user = $_POST['usuario'];
	$email = $_POST['email'];
	$password = md5($_POST['password']);
	$name = $_POST['nombre'];
	$surname1 = $_POST['apellido1'];
	$surname2 = $_POST['apellido2'];
	$dni_cif = $_POST['dni'];
	$address = $_POST['direccion'];
	$phone = $_POST['telefono'];
	
  	require_once 'connectdb.php';

	$sql1 = "INSERT INTO Usuarios(dni_cif, nombre, apellido1, apellido2, telefono, direccion, email) VALUES ('$dni_cif', '$name', '$surname1', '$surname2', '$phone', '$address', '$email')";
	$sql2 = "INSERT INTO Cuentas(dni_cif, usuario, password, rol, habilitado) VALUES ('$dni_cif', '$user', '$password', 3, 0)";
	if(mysqli_query($conn, $sql1) && mysqli_query($conn, $sql2)) {
		$result["success"] = "1";
		$result["message"] = "Usuario creado correctamente";
	} else {
		$sql3 = "DELETE FROM Usuarios WHERE dni_cif = '$dni_cif'";
		$sql4 = "DELETE FROM Cuentas WHERE dni_cif = '$dni_cif'";
		mysqli_query($conn, $sql3);
		mysqli_query($conn, $sql4);
		$result["success"] = "0";
		$result["message"] = "No se pudo crear el usuario";
	}
	echo json_encode($result);
	mysqli_close($conn);
}
?>