<?php
// Obtener los datos del formulario
$dni_cif = $_POST['dni'];

require_once 'connectdb.php';

// Consulta SQL para obtener la lista de visas del usuario proporcionado
$sql = "SELECT * FROM Tarjetas WHERE cuenta = '$dni_cif'";

$result['visaList'] = array();
$response = mysqli_query($conn, $sql);

if (mysqli_num_rows($response) > 0) {
	while ($row = mysqli_fetch_assoc($response)) {
		$index['numero_tarjeta'] = $row['numero_tarjeta']; 
		$index['cuenta'] = $row['cuenta']; 
		$index['saldo'] = $row['saldo']; 
		$index['nombre'] = $row['nombre']; 

		$currency = $row['moneda']; 
			
		$sql = "SELECT simbolo FROM Monedas WHERE id = $currency";
		
		$response2 = mysqli_query($conn, $sql);
		if (mysqli_num_rows($response2) == 1) {
			$row2 = mysqli_fetch_assoc($response2);
			$index['moneda'] = $row2['simbolo'];
			$result['success'] = "1";
			$result['message'] = "success";			
		}
		else {
			$result['success'] = "0";
			$result['message'] = "No hay monedas";				
		}		
		array_push($result['visaList'], $index);
	}
	
} else{
	$result['success'] = "0";
	$result['message'] = "No hay tarjetas";
}
mysqli_close($conn);
echo json_encode($result);
?>
