<?php
// Obtener los datos del formulario
$numVisa = $_POST['visa_number'];

require_once 'connectdb.php';

// Consulta SQL para verificar las credenciales del usuario
$sql = "SELECT dni_cif, usuario, rol, password FROM Cuentas 
WHERE dni_cif IN (
SELECT dni_cif FROM Usuarios WHERE email = '$numVisa')";

$response = mysqli_query($conn, $sql);

if (mysqli_num_rows($response) > 0) {
	$result['success'] = "1";
	$result['message'] = "Se encontró tarjeta con este número";
	$result['body'] = "true";
} else{
	$result['success'] = "1";
	$result['message'] = "No se encontró tarjeta con este número";
	$result['body'] = "false";
}

mysqli_close($conn);
echo json_encode($result);
?>
