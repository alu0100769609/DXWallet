<?php
	require_once 'connectdb.php';

// Consulta SQL para obtener la lista de monedas. 
$sql = "SELECT * FROM Monedas";

$result['currencies'] = array();
$response = mysqli_query($conn, $sql);

if (mysqli_num_rows($response) > 0) {
	while ($row = mysqli_fetch_assoc($response)) {
		$index['id'] = $row['id']; 
		$index['nombre'] = $row['nombre']; 
		$index['simbolo'] = $row['simbolo']; 
		$index['valor'] = $row['valor']; 
		
		$result['success'] = "1";
		$result['message'] = "success";	
		array_push($result['currencies'], $index);
	}
}
else {
	$result['success'] = "0";
	$result['message'] = "No hay monedas";				
}

mysqli_close($conn);
echo json_encode($result);
?>
