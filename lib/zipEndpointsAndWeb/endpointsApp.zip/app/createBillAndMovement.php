<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST'){
	$userVisaNumber = $_POST['userVisaNumber']; // Visa del usuario
	$shopVisaNumber = $_POST['shopVisaNumber']; // Visa de la tienda
	$amount = (double) $_POST['amount']; // Cantidad

	require_once 'connectdb.php';

	// Antes de nada inicializamos la variable result para poder añadir los mensajes más abajo
	$result["success"] = "1";
	$result["message"] = "";


	
	// Para crear la factura necesitamos numero_factura cif_comercio fecha importe moneda ticket(url) cobrado
	
	// numero_factura => FAC + rand de números
	// Bucle para comprobar que el número de factura no esté cogido
	$repeat = false;
	do {
		$number = "";
		for ($i = 0; $i < 4; $i++) {
			$digit = rand(0, 9);
			$number .= $digit;
		}
		$facNumber = "FAC" . $number;//////////////////////////////////////////////////////////////
		
		$sql = "SELECT * FROM Facturas WHERE numero_factura = '$facNumber'";
		$response = mysqli_query($conn, $sql);
		
		if (mysqli_num_rows($response) > 0) { // Ya existe el numero de factura
			$repeat = true;
		}
		else { // No existe el numero de factura
			$repeat = false;
		}
	} while ($repeat);
	
	// cif_comercio => cuenta de la tabla Tarjetas buscando por $shopVisaNumber
	$sql = "SELECT cuenta FROM Tarjetas WHERE numero_tarjeta = '$shopVisaNumber'";
	$response = mysqli_query($conn, $sql);
	if (mysqli_num_rows($response) > 0) { // Existe la cuenta
		$row = mysqli_fetch_assoc($response);
		$shopAccount = $row['cuenta'];///////////////////////////////////////////////////////////
	}
	else { // No existe el numero de cuenta de la tienda
		$result["success"] = "0";
		$result["message"] = "Error con la cuenta de la tienda";
	}
	
	// fecha => Datetime now
	$actualDate = date("Y-m-d");          ///////////////////////////////////////////////////////////

	// importe => $amount                 ///////////////////////////////////////////////////////////
	
	// moneda => moneda de la tabla Tarjetas buscando por $userVisaNumber
	$sql = "SELECT moneda FROM Tarjetas WHERE numero_tarjeta = '$userVisaNumber'";
	$response = mysqli_query($conn, $sql);
	if (mysqli_num_rows($response) > 0) { // Existe la cuenta
		$row = mysqli_fetch_assoc($response);
		$currency = $row['moneda'];    /////////////////////////////////////////////////////////
	}
	else { // No existe el numero de cuenta de la tienda
		$result["success"] = "0";
		$result["message"] = "Error con la moneda de la tarjeta";
	}
	
	// ticket => ruta "por defecto" (siempre la misma para el ejemplo)
	// Array de rutas de tickets
	$ticketRoutes = [
		"https://sebt.es/adexe/dxwallet/appBills/Ticket1.PNG",
		"https://sebt.es/adexe/dxwallet/appBills/Ticket2.PNG",
		"https://sebt.es/adexe/dxwallet/appBills/Ticket3.jpg",
		"https://sebt.es/adexe/dxwallet/appBills/Ticket4.jpg",
		"https://sebt.es/adexe/dxwallet/appBills/Ticket5.jpg"
	];

	// Seleccionar una ruta aleatoria
	$randomTicketRoute = $ticketRoutes[array_rand($ticketRoutes)]; ////////////////////////////////
	// Ya tenemos todos los datos marcados por "////////////////////////" ahora creamos la factura correspondiente
	
	$sql = "INSERT INTO Facturas (numero_factura, cif_comercio, fecha, importe, moneda, ticket, cobrado) VALUES ('$facNumber', '$shopAccount', '$actualDate', $amount, '$currency', '$randomTicketRoute', 1);";
	if(mysqli_query($conn, $sql)) {
		$result["success"] = "1";
		$result["message"] = "Factura creada correctamente";
	}
	else {
		$result["success"] = "0";
		$result["message"] = "No se pudo crear la factura";
	}
	
	// Después de tener la factura, creamos el movimiento
	$sql = "INSERT INTO Movimientos (numero_tarjeta, numero_factura) VALUES ('$userVisaNumber', '$facNumber');";
	if(mysqli_query($conn, $sql)) {
		$result["success"] = "1";
		$result["message"] = "Movimiento creado correctamente";
	}
	else {
		$result["success"] = "0";
		$result["message"] = "No se pudo crear el movimiento";
	}

	echo json_encode($result);
	mysqli_close($conn);	
}
?>