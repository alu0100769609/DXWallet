<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST'){
	$user = $_POST['usuario'];
	$email = $_POST['email'];
	$name = $_POST['nombre'];
	$surname1 = $_POST['apellido1'];
	$surname2 = $_POST['apellido2'];
	$dni_cif = $_POST['dni'];
	$address = $_POST['direccion'];
	$phone = $_POST['telefono'];
	
	require_once 'connectdb.php';

	$sql1 = "UPDATE Usuarios SET nombre = '$name', apellido1 = '$surname1', apellido2 = '$surname2', telefono = '$phone', direccion = '$address', email = '$email' WHERE dni_cif = '$dni_cif'";

	$sql2 = "UPDATE Cuentas SET usuario = '$user' WHERE dni_cif = '$dni_cif'";
	if(mysqli_query($conn, $sql1)) {
		if(mysqli_query($conn, $sql2)) {
			$result["success"] = "1";
			$result["message"] = "Usuario modificado correctamente";
		}
		else {
			$result["success"] = "0";
			$result["message"] = "Actualizado usuario, no cuenta";			
		}
	} else {
		$result["success"] = "0";
		$result["message"] = "No se pudieron modificar los datos";
	}
	echo json_encode($result);
	mysqli_close($conn);
}
?>