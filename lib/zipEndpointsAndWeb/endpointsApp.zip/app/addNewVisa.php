<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST'){
	$dni = $_POST['dni'];
	$visaName = $_POST['nombre_tarjeta'];
	$visaNumber = $_POST['numero_tarjeta'];
	$currency = $_POST['id_moneda'];
	
	require_once 'connectdb.php';

	$sql1 = "INSERT INTO Tarjetas(numero_tarjeta, nombre, cuenta, moneda, saldo) VALUES ('$visaNumber', '$visaName', '$dni', '$currency', 0)";
	if(mysqli_query($conn, $sql1)) {
		$result["success"] = "1";
		$result["message"] = "Tarjeta creada correctamente";
	} else {
		$result["success"] = "0";
		$result["message"] = "No se pudo crear la tarjeta";
	}
	echo json_encode($result);
	mysqli_close($conn);
}
?>