<?php
// Obtener los datos del formulario
$dni = $_POST['dni'];
$oldPassword = md5($_POST['oldPassword']);
$password1 = md5($_POST['password1']);
$password2 = md5($_POST['password2']);

require_once 'connectdb.php';

// Consulta SQL para recuperar la contraseña del usuario
$sql = "SELECT password FROM Cuentas WHERE dni_cif  = '$dni'";

$response = mysqli_query($conn, $sql);

if (mysqli_num_rows($response) === 1) {
	$row = mysqli_fetch_assoc($response);
	if ($oldPassword == $row['password']) {
		if ($password1 == $password2) {
			$sql = "UPDATE Cuentas SET password = '$password1' WHERE dni_cif = '$dni'";
			if(mysqli_query($conn, $sql)) {
				$result['success'] = "1";
				$result['message'] = "Contraseña actualizada";			
			}
			else {
				$result['success'] = "0";
				$result['message'] = "No se pudo actualizar la contraseña";				
			}
		}
		else {
			$result['success'] = "0";
			$result['message'] = "Las contraseñas no son iguales";
		}
	} else {
		$result['success'] = "0";
		$result['message'] = "Contraseña incorrecta";
	}
} else{
	$result['success'] = "0";
	$result['message'] = "Usuario incorrecto o no registrado";
}

mysqli_close($conn);
echo json_encode($result);
?>
