<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST'){
	$visaNumber = $_POST['visaNumber'];
	$addAmount = (double) $_POST['amount'];
	
	require_once 'connectdb.php';

	$sql1 = "SELECT saldo FROM Tarjetas WHERE numero_tarjeta = '$visaNumber'";

	$response = mysqli_query($conn, $sql1);
	if(mysqli_num_rows($response) === 1) {
		if ($addAmount != "0") {
			$row = mysqli_fetch_assoc($response);
			
			$balance = (double) $row["saldo"];
			$newBalance = $balance + $addAmount;
			
			$sql2 = "UPDATE Tarjetas SET saldo = $newBalance WHERE numero_tarjeta = '$visaNumber'";
			if (mysqli_query($conn, $sql2)) {
				$result["success"] = "1";
				$result["message"] = "Incremento satisfactorio";
			}
			else {
				$result["success"] = "0";
				$result["message"] = "Error al actualizar el saldo";
			}
		}
		else {
			$result["success"] = "0";
			$result["message"] = "No se ha especificado cantidad a ingresar";

		}
	
	} else {
		$result["success"] = "0";
		$result["message"] = "Tarjeta equivocada";
	}
	echo json_encode($result);
	mysqli_close($conn);
}
?>