<?php
// Obtener los datos del formulario
$dni = $_POST['dni'];

require_once 'connectdb.php';

// Consulta SQL para obtener todos los datos del usuario, ya sean personales o de la cuenta
$sql = "SELECT C.dni_cif, C.usuario, C.password, C.rol, C.habilitado, U.nombre, U.apellido1, U.apellido2, U.telefono, U.direccion, U.email
        FROM Cuentas C
        INNER JOIN Usuarios U ON C.dni_cif = U.dni_cif
        WHERE C.dni_cif = '$dni'";

$result['data'] = array();
$response = mysqli_query($conn, $sql);




if (mysqli_num_rows($response) > 0) {
	$row = mysqli_fetch_assoc($response);
	$index['email'] = $row['email']; 
	$index['dni'] = $row['dni_cif']; 
	$index['direccion'] = $row['direccion']; 
	$index['telefono'] = $row['telefono']; 
	$index['apellido2'] = $row['apellido2']; 
	$index['apellido1'] = $row['apellido1']; 
	$index['nombre'] = $row['nombre'];
	$index['usuario'] = $row['usuario']; 
	$index['habilitado'] = $row['habilitado']; 

	$result['success'] = "1";
	$result['message'] = "success";			
	array_push($result['data'], $index);
	
} else{
	$result['success'] = "0";
	$result['message'] = "Error al recuperar datos de usuario";
}
mysqli_close($conn);
echo json_encode($result);
?>
