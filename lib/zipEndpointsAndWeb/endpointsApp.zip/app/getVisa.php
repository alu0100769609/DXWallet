<?php
// Obtener los datos del formulario
$visaNumber = $_POST['visa_number'];

require_once 'connectdb.php';

// Consulta SQL para obtener la lista de visas del usuario proporcionado
$sql = "SELECT * FROM Tarjetas WHERE numero_tarjeta = '$visaNumber'";

$result['visa'] = array();
$response = mysqli_query($conn, $sql);

if (mysqli_num_rows($response) > 0) {
	$row = mysqli_fetch_assoc($response);
	$index['numero_tarjeta'] = $row['numero_tarjeta']; 
	$index['nombre'] = $row['nombre']; 
	$index['cuenta'] = $row['cuenta']; 
	$index['saldo'] = $row['saldo']; 

	$currency = $row['moneda']; 
		
	$sql = "SELECT simbolo FROM Monedas WHERE id = $currency";
	
	$response2 = mysqli_query($conn, $sql);
	if (mysqli_num_rows($response2) == 1) {
		$row2 = mysqli_fetch_assoc($response2);
		$index['moneda'] = $row2['simbolo'];
		$result['success'] = "1";
		$result['message'] = "success";			
	}
	else {
		$result['success'] = "0";
		$result['message'] = "No hay monedas";				
	}
	array_push($result['visa'], $index);
	
} else{
	$result['success'] = "0";
	$result['message'] = "No hay tarjeta";
}
mysqli_close($conn);
echo json_encode($result);
?>
