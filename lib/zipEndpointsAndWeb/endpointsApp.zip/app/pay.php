<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST'){
	$incomeVisaNumber = $_POST['incomeVisaNumber']; // Visa del usuario
	$outcomeVisaNumber = $_POST['outcomeVisaNumber']; // Visa de la tienda
	$amount = (double) $_POST['amount'];
	
	require_once 'connectdb.php';

	// Verificamos el saldo de la tarjeta del usuario
	$sql1 = "SELECT saldo FROM Tarjetas WHERE numero_tarjeta = '$incomeVisaNumber'";
	
	$response = mysqli_query($conn, $sql1);
	if(mysqli_num_rows($response) === 1) {
		$row = mysqli_fetch_assoc($response);			
		$balance = (double) $row["saldo"];
		if ($balance >= $amount) {
			// Hacemos el traspaso de dinero (restamos en income y sumamos en outcome)
			// Nos aseguramos que la cuenta de destino también existe
			$sql2 = "SELECT saldo FROM Tarjetas WHERE numero_tarjeta = '$outcomeVisaNumber'";
			$response2 = mysqli_query($conn, $sql2);
			if(mysqli_num_rows($response2) === 1) {
				$row = mysqli_fetch_assoc($response2);			
				$balance2 = (double) $row["saldo"];
				
				// Restamos el saldo de la cuenta 1 y aumentamos en la cuenta 2
				$balance -= $amount;
				$balance2 += $amount;
				
				// Hacemos ambas inserciones en la tabla
				$sql1 = "UPDATE Tarjetas SET saldo = $balance WHERE numero_tarjeta = '$incomeVisaNumber'";
				$sql2 = "UPDATE Tarjetas SET saldo = $balance2 WHERE numero_tarjeta = '$outcomeVisaNumber'";
				if (mysqli_query($conn, $sql1) && mysqli_query($conn, $sql2)) {
					$result["success"] = "1";
					$result["message"] = "Pago completado";
				}
				else {
					$result["success"] = "0";
					$result["message"] = "Error al procesar el pago";
				}
			}
			else {
				$result["success"] = "0";
				$result["message"] = "Error en cuenta destino";			
			}
		}
		else {
			$result["success"] = "0";
			$result["message"] = "No dispone de saldo suficiente";			
		}
	}
	else {
		$result["success"] = "0";
		$result["message"] = "Problema con la tarjeta";
	}
	echo json_encode($result);
	mysqli_close($conn);
}
?>