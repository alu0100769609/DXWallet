<?php
// Obtener los datos del formulario
$email = $_POST['email'];
$pass = md5($_POST['password']);

require_once 'connectdb.php';

// Consulta SQL para verificar las credenciales del usuario
$sql = "SELECT dni_cif, usuario, rol, password FROM Cuentas 
WHERE dni_cif IN (
SELECT dni_cif FROM Usuarios WHERE email = '$email')";

$result['login'] = array();
$response = mysqli_query($conn, $sql);

if (mysqli_num_rows($response) === 1) {
	$row = mysqli_fetch_assoc($response);
	if ($pass == $row['password']) {
		if ($row['rol'] == 3) {
			$index['dni_cif'] = $row['dni_cif']; 
			$index['usuario'] = $row['usuario']; 
			$index['rol'] = $row['rol']; 

			array_push($result['login'], $index);

			$result['success'] = "1";
			$result['message'] = "success";			
		}
		else {
			$result['success'] = "0";
			$result['message'] = "Sólo los usuarios cliente pueden acceder a la aplicación";
		}
	} else {
		$result['success'] = "0";
		$result['message'] = "Contraseña incorrecta";
	}
} else{
	$result['success'] = "0";
	$result['message'] = "Usuario incorrecto o no registrado";
}

mysqli_close($conn);
echo json_encode($result);
?>
