<?php
// Obtener los datos del formulario
$dni = $_POST['dni'];
$visaNumber = $_POST['visaNumber'];
//$dni = '11111111A';//$_POST['dni'];
//$visaNumber = '1234123412341234';//$_POST['visaNumber'];

// Hay que traer nombre tienda, cantidad y fecha.
// Comprobamos que el usuario es el dueño de la tarjetas
// Buscamos en los movimientos, los que tienen la tarjeta asociada
// Cogemos los números de factura y buscamos las facturas en la tabla de facturas.
// De la tabla de factura sacamos la fecha y el importe, y con el cif del comercio
// Buscamos en la tabla de usuarios el nombre del comercio que tiene ese cif


require_once 'connectdb.php';

$result['movementsList'] = array();

// Comprobamos que el usuario es el dueño de la tarjeta en la tabla de Tarjetas
//$consultaTarjeta = "SELECT * FROM Tarjetas WHERE cuenta = '$dni' AND numero_tarjeta = '$visaNumber'";
$consultaTarjeta = "SELECT * FROM Tarjetas WHERE cuenta = '$dni' AND numero_tarjeta = '$visaNumber'";

// Si no se obtiene un resultado, significa que el usuario no es el dueño de la tarjeta
$resultadoTarjeta = mysqli_query($conn, $consultaTarjeta);

if (mysqli_num_rows($resultadoTarjeta) > 0) {
    // Buscamos en Movimientos las filas que tienen la tarjeta asociada
    $consultaMovimientos = "SELECT * FROM Movimientos WHERE numero_tarjeta = '$visaNumber'";

    // Ejecutamos la consulta y obtenemos los resultados
    $resultadoMovimientos = mysqli_query($conn, $consultaMovimientos);

    $facturas = array();
    while ($filaMovimiento = mysqli_fetch_assoc($resultadoMovimientos)) {
        $numeroFactura = $filaMovimiento['numero_factura'];

        // Consultamos la tabla Facturas para obtener la información necesaria
        $consultaFactura = "SELECT fecha, importe, cif_comercio, ticket FROM Facturas WHERE numero_factura = '$numeroFactura'";

        // Ejecutamos la consulta y obtenemos los resultados
        $resultadoFactura = mysqli_query($conn, $consultaFactura);
        $filaFactura = mysqli_fetch_assoc($resultadoFactura);

        // De la tabla Facturas sacamos la fecha, el importe y el cif del comercio
        $fecha = $filaFactura['fecha'];
        $importe = $filaFactura['importe'];
        $cifComercio = $filaFactura['cif_comercio'];
        $ticketURL = $filaFactura['ticket'];
				
		if (substr($importe, 0, 1) === '-') {
			// El importe tiene un signo "-" delante
			// Significa que es una devolución, lo dejamos positivo
			$importe = substr_replace($importe, "+", 0, 1);
		} else {
			// El importe no tiene un signo "-" delante
			// Significa que es un cobro, "Valor negativo en movimiento"
			$importe = "-" . $importe;
		}
		
		

        // Consultamos la tabla Usuarios para obtener el nombre del comercio
        $consultaComercio = "SELECT nombre FROM Usuarios WHERE dni_cif = '$cifComercio'";

        // Ejecutamos la consulta y obtenemos el resultado
        $resultadoComercio = mysqli_query($conn, $consultaComercio);
        $filaComercio = mysqli_fetch_assoc($resultadoComercio);
        $nombreComercio = $filaComercio['nombre'];

        // Paso 6: Metemos los valores en un array y lo devolvemos
		$index['nombre_tienda'] = $nombreComercio; 
		$index['cantidad'] = $importe; 
		$index['fecha'] = $fecha; 
		$index['ticketURL'] = $ticketURL; 

		$result['success'] = "1";
		$result['message'] = "success";

        // Agregamos la factura al array de facturas
		array_push($result['movementsList'], $index);
	}
	if ($result['movementsList'] == null) {
	$result['success'] = "0";
	$result['message'] = "No hay movimientos disponibles";
	}
}
else {
	// El usuario no es el dueño de la tarjeta
	$result['success'] = "0";
	$result['message'] = "No eres el dueño de la tarjeta consultada";
}
mysqli_close($conn);
echo json_encode($result);
?>
